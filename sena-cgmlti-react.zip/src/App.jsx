export default function App() {
  return (
    <div className="min-h-screen bg-gray-100 text-gray-800">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto flex justify-between items-center px-6 py-4">
          <h1 className="text-green-600 font-bold">SENA - CGMLTI</h1>
          <nav className="space-x-6 text-sm">
            <a href="#">Inicio</a>
            <a href="#">Programas</a>
            <a href="#">Contacto</a>
          </nav>
        </div>
      </header>

      <section className="bg-green-600 text-white text-center py-20">
        <h2 className="text-3xl font-bold mb-2">SERVICIO NACIONAL DE APRENDIZAJE</h2>
        <p className="mb-6">Formación para el trabajo</p>
        <button className="bg-white text-green-600 px-6 py-2 rounded-lg">
          Conocer más
        </button>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-16">
        <h3 className="text-center text-xl font-bold mb-10 border-b-2 border-green-600 inline-block">
          PROGRAMAS DE FORMACIÓN CGMLTI
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-10">
          {["ADSO","Animación 3D","Redes de Datos","Gestión Logística","Diseño Gráfico","Marketing Digital","Telecomunicaciones","Audiovisuales"].map((t,i)=>(
            <div key={i} className="bg-white rounded-xl shadow p-6 text-center">
              <div className="w-6 h-6 mx-auto mb-3 rounded-full bg-green-500"></div>
              <h4 className="font-bold">{t}</h4>
            </div>
          ))}
        </div>
      </section>

      <footer className="bg-white text-center text-xs py-4 text-gray-500">
        © 2025 Servicio Nacional de Aprendizaje - SENA
      </footer>
    </div>
  )
}